# Prompt Engineering: Few-shot, Chain-of-Thought and Structured Output

A hands-on, reproducible study of three prompt-engineering techniques, with every prompt, every raw model
output and the scoring code included.

| Experiment | Technique | Task | Measured |
|---|---|---|---|
| 1 | Zero-shot vs few-shot | Sentiment classification, 10 reviews (incl. sarcasm and mixed sentiment) | accuracy, output-format compliance |
| 2 | Direct answer vs chain-of-thought | 6 multi-step word problems | accuracy of the final number |
| 3 | Structured output (3 prompt iterations) | Messy text -> `{name, date, amount, currency}` JSON, 6 inputs with traps | valid JSON, schema match, field-level correctness |

**Final report:** `report/Prompt_Engineering_Report.pdf` (also `report/REPORT.md`, which GitHub renders directly).

## Repository layout

```
prompts.py           all prompt templates, test inputs and expected answers
evaluate.py          scoring functions (no dependencies)
run_experiments.py   calls the model, saves RAW outputs to results/raw_results.json
build_report.py      builds the PDF + Markdown report from the results and analysis.md
analysis.md          YOUR written analysis (the part reviewers read most closely)
results/             raw outputs (committed on purpose - they are the evidence)
report/              generated report
```

## How to run

1. Python 3.9+ and one dependency (only for the report): `pip install reportlab`
2. Get an API key from the OpenAI Platform or Google AI Studio and export it:
   ```bash
   export OPENAI_API_KEY=...        # or: export GEMINI_API_KEY=...
   ```
3. Run all experiments (50 API calls). Use the exact model name your provider lists:
   ```bash
   python run_experiments.py --provider openai --model <model-name>
   # or
   python run_experiments.py --provider gemini --model <model-name>
   ```
   Interrupted? Add `--resume`. The runner saves after every call.
4. Open `results/raw_results.json` or run step 5 and read the raw outputs. Then fill in `analysis.md`
   with your own observations (replace each `TODO`).
5. Build the report:
   ```bash
   python build_report.py
   ```

## Making the study stronger

- **Pick a model where differences can show.** Strong, recent models often score 100% on everything here.
  That is a legitimate finding, but running a smaller/cheaper model as well (`--out results/small_model.json`,
  then `python build_report.py --results results/small_model.json --pdf report/small_model.pdf`) usually shows
  where each technique matters.
- **Consistency test.** `--temperature 0.7 --runs 3 --out results/consistency.json` repeats every prompt three
  times; the report then adds a consistency column (share of items where all runs agree).
- **Iterate further.** Add a `v4` to `EXTRACTION` in `prompts.py`, re-run, and describe the failure it fixed.
  Add harder inputs to any test set. Keep the failures in the report.
- Few-shot examples and JSON-prompt examples are deliberately **not** in the test sets, so gains are not
  memorisation.

## Method notes

- Temperature 0 by default; exact model name, provider, temperature and date are recorded in the report.
- Scoring is automatic and rule-based (`evaluate.py`): sentiment by label match, math by the final number
  (`ANSWER:` line for chain-of-thought), JSON by `json.loads`, schema check, and per-field comparison.
- "Valid JSON as returned" is strict (`json.loads` on the raw text); "after cleanup" also accepts output wrapped in
  markdown fences. The report shows both so formatting problems are not hidden.
- Limitations: small test sets (6-10 items) give a coarse signal, not a statistically rigorous one; one model per
  run; the sentiment labels reflect one annotator's judgement.

## Integrity

Raw outputs in `results/raw_results.json` and in the report are exactly what the model returned. Please do not
edit them. `--provider mock` exists only to test the pipeline; its report is stamped
`MOCK_DO_NOT_SUBMIT`.

## Publishing to GitHub

```bash
git init
git add .
git commit -m "Prompt engineering experiments: few-shot, chain-of-thought, structured output"
git branch -M main
git remote add origin https://github.com/<you>/<repo>.git
git push -u origin main
```

Submit the repo link, or the direct link to `report/Prompt_Engineering_Report.pdf` / `report/REPORT.md`.
Never commit API keys (`.env` is git-ignored).

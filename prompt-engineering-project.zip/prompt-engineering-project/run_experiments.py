#!/usr/bin/env python3
"""
run_experiments.py - runs all three prompt-engineering experiments and saves the RAW model outputs.

Zero third-party dependencies (plain HTTPS via urllib).

Examples
  export OPENAI_API_KEY=sk-...
  python run_experiments.py --provider openai --model <model-name-you-have-access-to>

  export GEMINI_API_KEY=...            # key from Google AI Studio
  python run_experiments.py --provider gemini --model <model-name>

  # consistency experiment: repeat each prompt 3 times with some randomness
  python run_experiments.py --provider openai --model <m> --temperature 0.7 --runs 3 \
         --out results/consistency.json

  # wiring test only (fake outputs, clearly flagged as MOCK in the report)
  python run_experiments.py --provider mock
"""
import argparse
import datetime
import json
import os
import sys
import time
import urllib.error
import urllib.request

import evaluate as E
import prompts as P


# ---------------------------------------------------------------------------
# Providers
# ---------------------------------------------------------------------------

def _post(url: str, headers: dict, body: dict, timeout: int = 120) -> dict:
    req = urllib.request.Request(
        url, data=json.dumps(body).encode("utf-8"),
        headers={**headers, "Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def call_openai(prompt, model, json_mode, temperature, ctx):
    key = os.environ.get("OPENAI_API_KEY") or sys.exit("Set the OPENAI_API_KEY environment variable.")
    body = {"model": model, "messages": [{"role": "user", "content": prompt}], "temperature": temperature}
    if json_mode:
        body["response_format"] = {"type": "json_object"}
    headers = {"Authorization": f"Bearer {key}"}
    try:
        data = _post("https://api.openai.com/v1/chat/completions", headers, body)
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")
        if e.code == 400 and "temperature" in detail:  # some models only accept the default temperature
            body.pop("temperature")
            data = _post("https://api.openai.com/v1/chat/completions", headers, body)
        else:
            e.detail = detail
            raise
    return data["choices"][0]["message"]["content"]


def call_gemini(prompt, model, json_mode, temperature, ctx):
    key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY") \
        or sys.exit("Set the GEMINI_API_KEY environment variable (key from Google AI Studio).")
    gen_cfg = {"temperature": temperature}
    if json_mode:
        gen_cfg["responseMimeType"] = "application/json"
    body = {"contents": [{"parts": [{"text": prompt}]}], "generationConfig": gen_cfg}
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    data = _post(url, {"x-goog-api-key": key}, body)
    parts = data["candidates"][0]["content"]["parts"]
    return "".join(p.get("text", "") for p in parts)


def call_mock(prompt, model, json_mode, temperature, ctx):
    """Deterministic fake model - ONLY for testing the pipeline. Never submit its output."""
    exp, variant, i, expected = ctx["experiment"], ctx["variant"], ctx["id"], ctx["expected"]
    if exp == "sentiment":
        if variant == "zero_shot" and i % 4 == 0:
            return f"The sentiment of this text is {'neutral' if expected != 'neutral' else 'mixed'}."
        return expected
    if exp == "cot":
        if variant == "direct":
            return str(int(expected) + (3 if i % 2 == 0 else 0))
        return f"Step 1: set up the equations.\nStep 2: solve them.\nANSWER: {int(expected)}"
    if exp == "extraction":
        if variant == "v1_naive":
            return (f"Sure! The name is {expected['name']}, the amount is {expected['amount']} "
                    f"{expected['currency']}, and the date is {expected['date']}.")
        obj = dict(expected)
        if variant == "v2_schema":
            return "```json\n" + json.dumps(obj, indent=2, ensure_ascii=False) + "\n```"
        if i == 4:
            obj["date"] = "2026-04-09"
        return json.dumps(obj, ensure_ascii=False)
    return ""


PROVIDERS = {"openai": call_openai, "gemini": call_gemini, "mock": call_mock}


def call_with_retries(fn, *args, tries=5):
    waits = [5, 15, 30, 60]
    for attempt in range(tries):
        try:
            return fn(*args)
        except urllib.error.HTTPError as e:
            detail = getattr(e, "detail", "") or e.read().decode("utf-8", "replace")
            if e.code in (429, 500, 502, 503, 504) and attempt < tries - 1:
                wait = waits[min(attempt, len(waits) - 1)]
                print(f"    HTTP {e.code}; retrying in {wait}s ...", file=sys.stderr)
                time.sleep(wait)
                continue
            sys.exit(f"API error {e.code}: {detail[:600]}")
        except (urllib.error.URLError, TimeoutError) as e:
            if attempt < tries - 1:
                print(f"    network error ({e}); retrying ...", file=sys.stderr)
                time.sleep(5)
                continue
            sys.exit(f"Network error: {e}")


# ---------------------------------------------------------------------------
# Scoring dispatch
# ---------------------------------------------------------------------------

def score(experiment, variant, raw, expected):
    if experiment == "sentiment":
        return E.eval_sentiment(raw, expected)
    if experiment == "cot":
        return E.eval_number(raw, expected, marker=(variant == "cot"))
    return E.eval_json(raw, expected)


def save(path, payload):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--provider", choices=list(PROVIDERS), required=True)
    ap.add_argument("--model", help="model name exactly as your provider lists it (not needed for mock)")
    ap.add_argument("--experiments", nargs="+", default=list(P.EXPERIMENTS), choices=list(P.EXPERIMENTS))
    ap.add_argument("--temperature", type=float, default=0.0, help="default 0 for reproducibility")
    ap.add_argument("--runs", type=int, default=1, help="repeat each prompt N times (consistency test)")
    ap.add_argument("--delay", type=float, default=0.5, help="seconds between calls (rate limits)")
    ap.add_argument("--out", default="results/raw_results.json")
    ap.add_argument("--resume", action="store_true", help="continue an interrupted run, skipping finished calls")
    args = ap.parse_args()

    model = args.model or ("mock" if args.provider == "mock" else None)
    if not model:
        sys.exit("--model is required (e.g. the model name shown in the OpenAI Playground / Google AI Studio).")
    fn = PROVIDERS[args.provider]

    meta = {
        "provider": args.provider, "model": model, "temperature": args.temperature, "runs": args.runs,
        "started": datetime.datetime.now().isoformat(timespec="seconds"), "finished": None,
        "experiments": {
            name: {k: P.EXPERIMENTS[name][k] for k in ("title", "task", "goal", "items")}
            | {"variants": P.EXPERIMENTS[name]["variants"]}
            for name in args.experiments
        },
    }
    records = []
    if args.resume and os.path.exists(args.out):
        with open(args.out, encoding="utf-8") as f:
            old = json.load(f)
        if (old["meta"]["provider"], old["meta"]["model"], old["meta"]["temperature"]) == \
                (args.provider, model, args.temperature):
            records = old["records"]
            meta["started"] = old["meta"]["started"]
            print(f"Resuming: {len(records)} calls already saved.")
    done = {(r["experiment"], r["variant"], r["id"], r["run"]) for r in records}

    total = sum(len(P.EXPERIMENTS[n]["items"]) * len(P.EXPERIMENTS[n]["variants"]) * args.runs
                for n in args.experiments)
    n = 0
    for name in args.experiments:
        exp = P.EXPERIMENTS[name]
        for variant, vcfg in exp["variants"].items():
            for item in exp["items"]:
                for run in range(1, args.runs + 1):
                    n += 1
                    if (name, variant, item["id"], run) in done:
                        continue
                    prompt = P.render(vcfg["template"], input=item["input"])
                    ctx = {"experiment": name, "variant": variant, "id": item["id"], "expected": item["expected"]}
                    print(f"[{n}/{total}] {name} / {variant} / item {item['id']} / run {run}")
                    raw = call_with_retries(fn, prompt, model, vcfg["json_mode"], args.temperature, ctx)
                    records.append({
                        "experiment": name, "variant": variant, "id": item["id"], "run": run,
                        "prompt": prompt, "raw_output": raw, "expected": item["expected"],
                        "evaluation": score(name, variant, raw, item["expected"]),
                        "timestamp": datetime.datetime.now().isoformat(timespec="seconds"),
                    })
                    save(args.out, {"meta": meta, "records": records})  # save after every call
                    if args.provider != "mock":
                        time.sleep(args.delay)

    meta["finished"] = datetime.datetime.now().isoformat(timespec="seconds")
    save(args.out, {"meta": meta, "records": records})

    print("\nSummary (correct / total)")
    for name in args.experiments:
        for variant in P.EXPERIMENTS[name]["variants"]:
            rs = [r for r in records if r["experiment"] == name and r["variant"] == variant]
            print(f"  {name:11s} {variant:11s} {sum(r['evaluation']['correct'] for r in rs)}/{len(rs)}")
    print(f"\nRaw outputs saved to {args.out}\nNext: write your analysis in analysis.md, then run build_report.py")


if __name__ == "__main__":
    main()

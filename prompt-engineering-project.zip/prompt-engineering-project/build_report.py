#!/usr/bin/env python3
"""
build_report.py - turns results/raw_results.json + analysis.md into
  report/Prompt_Engineering_Report.pdf   (the file you submit)
  report/REPORT.md                       (same content, renders nicely on GitHub)

Requires: pip install reportlab
Raw model outputs are copied verbatim from the results file - nothing is paraphrased.
"""
import argparse
import datetime
import json
import os
import re
import sys
import textwrap
from xml.sax.saxutils import escape

EXP_ORDER = ["sentiment", "cot", "extraction"]
ANALYSIS_KEYS = {"sentiment": "Experiment 1", "cot": "Experiment 2", "extraction": "Experiment 3"}


# ---------------------------------------------------------------------------
# Data helpers
# ---------------------------------------------------------------------------

def recs(records, exp, variant):
    return sorted((r for r in records if r["experiment"] == exp and r["variant"] == variant),
                  key=lambda r: (r["id"], r["run"]))


def first_run(rs):
    return {r["id"]: r for r in rs if r["run"] == 1}


def frac(k, n):
    return f"{k}/{n} ({100 * k / n:.0f}%)" if n else "n/a"


def count(rs, key):
    return sum(1 for r in rs if r["evaluation"][key]), len(rs)


def consistency(rs, runs):
    if runs < 2:
        return "n/a (1 run)"
    by_id = {}
    for r in rs:
        by_id.setdefault(r["id"], []).append(json.dumps(r["evaluation"]["pred"], sort_keys=True))
    same = sum(1 for v in by_id.values() if len(set(v)) == 1)
    return frac(same, len(by_id))


def ids(lst):
    return ", ".join(str(i) for i in lst) if lst else "none"


# ---------------------------------------------------------------------------
# analysis.md
# ---------------------------------------------------------------------------

def load_analysis(path):
    sections, pending = {}, []
    if not os.path.exists(path):
        return sections, ["analysis.md not found"]
    text = re.sub(r"<!--.*?-->", "", open(path, encoding="utf-8").read(), flags=re.S)
    parts = re.split(r"^##\s+(.+)$", text, flags=re.M)
    for i in range(1, len(parts), 2):
        title, body = parts[i].strip(), parts[i + 1].strip()
        if "TODO" in body or not body:
            pending.append(title)
        else:
            sections[title] = body
    return sections, pending


def analysis_blocks(sections, key):
    body = next((v for k, v in sections.items() if k.startswith(key)), None)
    if body is None:
        return [("p", "[Analysis not written yet - fill in the matching section of analysis.md and rebuild.]")]
    blocks = []
    for para in re.split(r"\n\s*\n", body):
        lines = [l for l in para.strip().splitlines() if l.strip()]
        if not lines:
            continue
        if all(re.match(r"^\s*[-*]\s+", l) for l in lines):
            blocks.append(("bullets", [re.sub(r"^\s*[-*]\s+", "", l) for l in lines]))
        else:
            blocks.append(("p", " ".join(l.strip() for l in lines)))
    return blocks


# ---------------------------------------------------------------------------
# Report content (renderer-independent blocks)
#   ("title", text, subtitle) ("banner", text) ("h1"/"h2"/"h3", text) ("p", text)
#   ("bullets", [..]) ("table", header, rows, widths_mm) ("code", label, text) ("pagebreak",)
#   table cells: str, or (str, "ok" | "bad")
# ---------------------------------------------------------------------------

def mark(ok, text=None):
    return (text or ("correct" if ok else "WRONG"), "ok" if ok else "bad")


def per_item_table(exp_name, emeta, records, widths, show_input=True):
    variants = list(emeta["variants"])
    firsts = {v: first_run(recs(records, exp_name, v)) for v in variants}
    header = ["#"] + (["Input"] if show_input else []) + ["Expected"] + [emeta["variants"][v]["label"] for v in variants]
    rows = []
    for item in emeta["items"]:
        exp_val = item["expected"]
        exp_txt = json.dumps(exp_val, ensure_ascii=False) if isinstance(exp_val, dict) else \
            (str(int(exp_val)) if isinstance(exp_val, float) and exp_val.is_integer() else str(exp_val))
        row = [str(item["id"])] + ([item["input"]] if show_input else []) + [exp_txt]
        for v in variants:
            r = firsts[v].get(item["id"])
            if r is None:
                row.append("-")
                continue
            ev = r["evaluation"]
            if exp_name == "extraction":
                if ev["correct"]:
                    row.append(mark(True, "valid, schema OK, all fields correct" if ev["valid_json_raw"]
                                    else "correct, but only after stripping fences/extra text"))
                else:
                    why = []
                    if not ev["valid_json_raw"]:
                        why.append("raw output not valid JSON" if ev["valid_json_cleaned"] else "no parseable JSON")
                    if ev["valid_json_cleaned"] and not ev["schema_ok"]:
                        why.append("schema mismatch")
                    if ev["field_errors"] and ev["field_errors"] != ["no parseable JSON"]:
                        why.append("wrong: " + ", ".join(ev["field_errors"]))
                    row.append(mark(False, "FAIL - " + "; ".join(why)))
            else:
                pred = ev["pred"]
                if isinstance(pred, float) and pred.is_integer():
                    pred = int(pred)
                row.append(mark(ev["correct"], f"{pred} ({'correct' if ev['correct'] else 'WRONG'})"))
        rows.append(row)
    return ("table", header, rows, widths)


def compare_observations(emeta, records, exp_name):
    a, b = list(emeta["variants"])[:2]
    fa, fb = first_run(recs(records, exp_name, a)), first_run(recs(records, exp_name, b))
    common = sorted(set(fa) & set(fb))
    la, lb = emeta["variants"][a]["label"], emeta["variants"][b]["label"]
    fixed = [i for i in common if not fa[i]["evaluation"]["correct"] and fb[i]["evaluation"]["correct"]]
    broke = [i for i in common if fa[i]["evaluation"]["correct"] and not fb[i]["evaluation"]["correct"]]
    both = [i for i in common if not fa[i]["evaluation"]["correct"] and not fb[i]["evaluation"]["correct"]]
    return ["Measured, from the raw outputs (first run):",
            f"- Wrong with {la} but right with {lb}: items {ids(fixed)}",
            f"- Right with {la} but wrong with {lb}: items {ids(broke)}",
            f"- Wrong with both: items {ids(both)}"]


def prompt_blocks(emeta):
    blocks = [("h3", "Prompts used (verbatim; {input} is replaced by each test input)")]
    for v in emeta["variants"].values():
        extra = "  |  API JSON mode: ON" if v["json_mode"] else ""
        blocks.append(("code", f"{v['label']} - {v['description']}{extra}", v["template"]))
    return blocks


def raw_output_blocks(exp_name, emeta, records, runs):
    blocks = [("h3", "Raw model outputs (verbatim, unedited)"),
              ("p", "Text below is exactly what the model returned. Lines are wrapped for page width only.")]
    for item in emeta["items"]:
        shown = item["input"] if exp_name != "extraction" else item["input"]
        blocks.append(("p", f"**Item {item['id']}** - {shown}"))
        for v, vcfg in emeta["variants"].items():
            for r in (x for x in recs(records, exp_name, v) if x["id"] == item["id"]):
                label = vcfg["label"] + (f" - run {r['run']}" if runs > 1 else "")
                blocks.append(("code", label, r["raw_output"]))
    return blocks


def build_blocks(data, sections, pending, is_mock):
    meta, records = data["meta"], data["records"]
    runs = meta.get("runs", 1)
    blocks = [("title", "Prompt Engineering Report",
               "Few-shot prompting, chain-of-thought and structured output")]
    if is_mock:
        blocks.append(("banner", "MOCK DATA - these outputs were generated by a fake test model to check the "
                                 "pipeline. DO NOT SUBMIT THIS FILE. Re-run run_experiments.py with a real model."))
    blocks.append(("p", f"**Model:** {meta['model']} ({meta['provider']})  |  **Temperature:** {meta['temperature']}  |  "
                        f"**Runs per prompt:** {runs}  |  **Run date:** {meta['started'][:10]}"))
    blocks.append(("p", "All prompts, test inputs and expected answers are in the repository (prompts.py). "
                        "All model outputs below are copied verbatim from results/raw_results.json. "
                        "Scoring code is in evaluate.py."))

    # --- summary
    blocks.append(("h1", "Results at a glance"))
    rows = []
    for name in EXP_ORDER:
        if name not in meta["experiments"]:
            continue
        em = meta["experiments"][name]
        for v, vcfg in em["variants"].items():
            rs = recs(records, name, v)
            k, n = count(rs, "correct")
            extra = ""
            if name == "extraction":
                extra = f"valid JSON as returned: {frac(*count(rs, 'valid_json_raw'))}"
            elif name == "sentiment":
                extra = f"exact one-word format: {frac(*count(rs, 'format_ok'))}"
            else:
                extra = f"followed answer format: {frac(*count(rs, 'format_ok'))}"
            rows.append([em["title"].split(" - ")[0], vcfg["label"], frac(k, n), extra, consistency(rs, runs)])
    blocks.append(("table", ["Experiment", "Prompt", "Accuracy", "Format compliance", "Consistency"], rows,
                   [24, 50, 28, 46, 26]))

    # --- experiments
    for name in EXP_ORDER:
        if name not in meta["experiments"]:
            continue
        em = meta["experiments"][name]
        blocks.append(("pagebreak",))
        blocks.append(("h1", em["title"]))
        blocks.append(("p", f"**Task:** {em['task']}"))
        blocks.append(("p", f"**Goal:** {em['goal']}"))
        blocks += prompt_blocks(em)

        blocks.append(("h3", "Results"))
        if name == "sentiment":
            rows = []
            for v, vcfg in em["variants"].items():
                rs = recs(records, name, v)
                rows.append([vcfg["label"], frac(*count(rs, "correct")), frac(*count(rs, "format_ok")),
                             consistency(rs, runs)])
            blocks.append(("table", ["Prompt", "Accuracy", "Replied with exactly one label", "Consistency"], rows,
                           [60, 34, 50, 30]))
            blocks.append(per_item_table(name, em, records, [8, 62, 20, 42, 42]))
            obs = compare_observations(em, records, name)
            blocks += [("p", obs[0]), ("bullets", [l[2:] for l in obs[1:]])]
        elif name == "cot":
            blocks.append(("p", "**Problems**"))
            blocks.append(("bullets", [f"P{it['id']}: {it['input']}" for it in em["items"]]))
            rows = []
            for v, vcfg in em["variants"].items():
                rs = recs(records, name, v)
                rows.append([vcfg["label"], frac(*count(rs, "correct")), frac(*count(rs, "format_ok")),
                             consistency(rs, runs)])
            blocks.append(("table", ["Prompt", "Accuracy (final number)", "Followed answer format", "Consistency"],
                           rows, [50, 44, 46, 34]))
            blocks.append(per_item_table(name, em, records, [10, 24, 70, 70], show_input=False))
            obs = compare_observations(em, records, name)
            blocks += [("p", obs[0]), ("bullets", [l[2:] for l in obs[1:]])]
        else:
            rows = []
            for v, vcfg in em["variants"].items():
                rs = recs(records, name, v)
                rows.append([vcfg["label"], frac(*count(rs, "valid_json_raw")), frac(*count(rs, "valid_json_cleaned")),
                             frac(*count(rs, "schema_ok")), frac(*count(rs, "correct")), consistency(rs, runs)])
            blocks.append(("table", ["Prompt", "Valid JSON as returned", "Valid JSON after cleanup",
                                     "Schema OK", "All fields correct", "Consistency"], rows,
                           [44, 26, 28, 24, 26, 26]))
            blocks.append(("p", "'As returned' means json.loads() succeeded on the raw output. 'After cleanup' also "
                                "accepts JSON wrapped in markdown fences or chatter. 'All fields correct' requires "
                                "the exact schema and every value matching the expected answer."))
            blocks.append(per_item_table(name, em, records, [7, 40, 32, 32, 32, 32]))
            fails = []
            for v, vcfg in em["variants"].items():
                for r in recs(records, name, v):
                    if not r["evaluation"]["correct"]:
                        fails.append(f"{vcfg['label']}, item {r['id']}"
                                     + (f" (run {r['run']})" if runs > 1 else "") + ": "
                                     + ", ".join(r["evaluation"]["field_errors"] or ["schema mismatch"]))
            blocks.append(("p", "**Failures, by prompt version**"))
            blocks.append(("bullets", fails or ["None - every output was fully correct."]))

        blocks += raw_output_blocks(name, em, records, runs)
        blocks.append(("h3", "Analysis"))
        blocks += analysis_blocks(sections, ANALYSIS_KEYS[name])

    blocks.append(("pagebreak",))
    blocks.append(("h1", "Overall lessons"))
    blocks += analysis_blocks(sections, "Overall")
    blocks.append(("h1", "Reproduce"))
    blocks.append(("code", "Commands",
                   "pip install reportlab\n"
                   f"python run_experiments.py --provider {meta['provider']} --model {meta['model']}"
                   f" --temperature {meta['temperature']} --runs {runs}\n"
                   "python build_report.py"))
    return blocks


# ---------------------------------------------------------------------------
# Markdown renderer
# ---------------------------------------------------------------------------

def md_cell(c):
    text = c[0] if isinstance(c, tuple) else c
    return text.replace("|", "\\|").replace("\n", "<br>")


def fence_for(text):
    longest = max([len(m) for m in re.findall(r"`+", text)] + [2])
    return "`" * (longest + 1)


def render_md(blocks):
    out = []
    for b in blocks:
        kind = b[0]
        if kind == "title":
            out += [f"# {b[1]}", f"*{b[2]}*", ""]
        elif kind == "banner":
            out += [f"> **{b[1]}**", ""]
        elif kind in ("h1", "h2", "h3"):
            out += [("##" if kind == "h1" else "###" if kind == "h2" else "####") + " " + b[1], ""]
        elif kind == "p":
            out += [b[1], ""]
        elif kind == "bullets":
            out += [f"- {x}" for x in b[1]] + [""]
        elif kind == "table":
            _, header, rows, _w = b
            out.append("| " + " | ".join(header) + " |")
            out.append("|" + "|".join(["---"] * len(header)) + "|")
            out += ["| " + " | ".join(md_cell(c) for c in row) + " |" for row in rows]
            out.append("")
        elif kind == "code":
            f = fence_for(b[2])
            out += [f"**{b[1]}**", "", f + "text", b[2], f, ""]
    return "\n".join(out)


# ---------------------------------------------------------------------------
# PDF renderer
# ---------------------------------------------------------------------------

def setup_fonts():
    """Prefer a Unicode TrueType family so symbols like the rupee sign and accents print correctly."""
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    candidates = [
        ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
         "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"),
        ("/usr/share/fonts/dejavu/DejaVuSans.ttf", "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf",
         "/usr/share/fonts/dejavu/DejaVuSansMono.ttf"),
        ("C:/Windows/Fonts/arial.ttf", "C:/Windows/Fonts/arialbd.ttf", "C:/Windows/Fonts/consola.ttf"),
        ("/Library/Fonts/Arial Unicode.ttf", "/Library/Fonts/Arial Unicode.ttf", "/System/Library/Fonts/Menlo.ttc"),
    ]
    for reg, bold, mono in candidates:
        if all(os.path.exists(p) for p in (reg, bold, mono)):
            try:
                pdfmetrics.registerFont(TTFont("Body", reg))
                pdfmetrics.registerFont(TTFont("Body-Bold", bold))
                pdfmetrics.registerFont(TTFont("Mono", mono))
                pdfmetrics.registerFontFamily("Body", normal="Body", bold="Body-Bold", italic="Body", boldItalic="Body-Bold")
                return "Body", "Body-Bold", "Mono", True
            except Exception:
                continue
    print("Warning: no Unicode font found; characters outside Latin-1 will print as '?'.", file=sys.stderr)
    return "Helvetica", "Helvetica-Bold", "Courier", False


def render_pdf(blocks, path, footer_text):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import (PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle,
                                    KeepTogether, ListFlowable, ListItem)

    body, bold, mono, unicode_ok = setup_fonts()

    def san(text):
        if unicode_ok:
            return text
        return text.encode("latin-1", "replace").decode("latin-1")

    def inline(text):
        t = escape(san(text))
        t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
        t = re.sub(r"`(.+?)`", rf'<font face="{mono}">\1</font>', t)
        return t.replace("\n", "<br/>")

    S = {
        "title": ParagraphStyle("title", fontName=bold, fontSize=24, leading=28, spaceAfter=4),
        "sub": ParagraphStyle("sub", fontName=body, fontSize=12, leading=16, textColor=colors.HexColor("#555555"), spaceAfter=10),
        "h1": ParagraphStyle("h1", fontName=bold, fontSize=16, leading=20, spaceBefore=10, spaceAfter=6,
                             textColor=colors.HexColor("#0b3d91")),
        "h3": ParagraphStyle("h3", fontName=bold, fontSize=11.5, leading=15, spaceBefore=10, spaceAfter=4),
        "p": ParagraphStyle("p", fontName=body, fontSize=9.5, leading=13.5, spaceAfter=5),
        "cell": ParagraphStyle("cell", fontName=body, fontSize=8, leading=10.5),
        "head": ParagraphStyle("head", fontName=bold, fontSize=8, leading=10.5, textColor=colors.white),
        "label": ParagraphStyle("label", fontName=bold, fontSize=8.5, leading=11, spaceBefore=6, spaceAfter=7,
                                textColor=colors.HexColor("#333333")),
        "code": ParagraphStyle("code", fontName=mono, fontSize=7.6, leading=9.8, backColor=colors.HexColor("#f6f8fa"),
                               borderColor=colors.HexColor("#d0d7de"), borderWidth=0.5, borderPadding=4,
                               spaceAfter=8, leftIndent=4, rightIndent=4),
        "banner": ParagraphStyle("banner", fontName=bold, fontSize=10, leading=14, textColor=colors.white,
                                 backColor=colors.HexColor("#cf222e"), borderPadding=8, spaceAfter=12),
    }

    def wrap_code(text, width=100):
        lines = []
        for line in san(text).replace("\t", "    ").split("\n"):
            if not line.strip():
                lines.append("")
                continue
            lines += textwrap.wrap(line, width, replace_whitespace=False, drop_whitespace=False,
                                   break_long_words=True) or [""]
        esc = "<br/>".join(escape(l) for l in lines)
        return esc.replace("  ", "&nbsp;&nbsp;")

    flow = []
    for b in blocks:
        kind = b[0]
        if kind == "title":
            flow += [Paragraph(inline(b[1]), S["title"]), Paragraph(inline(b[2]), S["sub"])]
        elif kind == "banner":
            flow.append(Paragraph(inline(b[1]), S["banner"]))
        elif kind == "h1":
            flow.append(Paragraph(inline(b[1]), S["h1"]))
        elif kind in ("h2", "h3"):
            flow.append(Paragraph(inline(b[1]), S["h3"]))
        elif kind == "p":
            flow.append(Paragraph(inline(b[1]), S["p"]))
        elif kind == "bullets":
            items = [ListItem(Paragraph(inline(x), S["p"]), leftIndent=12) for x in b[1]]
            flow.append(ListFlowable(items, bulletType="bullet", start="\u2022" if unicode_ok else "-",
                                     leftIndent=12, bulletFontName=body))
            flow.append(Spacer(1, 4))
        elif kind == "table":
            _, header, rows, widths = b
            colw = [w * mm for w in widths]
            scale = (174 * mm) / sum(colw)
            colw = [w * scale for w in colw]
            data = [[Paragraph(inline(h), S["head"]) for h in header]]
            style = [("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0b3d91")),
                     ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#c8ccd0")),
                     ("VALIGN", (0, 0), (-1, -1), "TOP"),
                     ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f6f8fa")]),
                     ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                     ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]
            for row in rows:
                cells = []
                for c in row:
                    if isinstance(c, tuple):
                        col = "#1a7f37" if c[1] == "ok" else "#cf222e"
                        cells.append(Paragraph(f'<font color="{col}"><b>{inline(c[0])}</b></font>', S["cell"]))
                    else:
                        cells.append(Paragraph(inline(c), S["cell"]))
                data.append(cells)
            flow.append(Table(data, colWidths=colw, repeatRows=1, style=TableStyle(style)))
            flow.append(Spacer(1, 6))
        elif kind == "code":
            flow.append(Paragraph(inline(b[1]), S["label"]))
            flow.append(Paragraph(wrap_code(b[2]), S["code"]))
        elif kind == "pagebreak":
            flow.append(PageBreak())

    def on_page(canvas, doc):
        canvas.saveState()
        canvas.setFont(body, 7.5)
        canvas.setFillColor(colors.HexColor("#666666"))
        canvas.drawString(18 * mm, 10 * mm, san(footer_text))
        canvas.drawRightString(192 * mm, 10 * mm, f"Page {doc.page}")
        canvas.restoreState()

    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    doc = SimpleDocTemplate(path, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm,
                            topMargin=16 * mm, bottomMargin=18 * mm,
                            title="Prompt Engineering Report", author="")
    doc.build(flow, onFirstPage=on_page, onLaterPages=on_page)


# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results/raw_results.json")
    ap.add_argument("--analysis", default="analysis.md")
    ap.add_argument("--pdf", default="report/Prompt_Engineering_Report.pdf")
    ap.add_argument("--md", default="report/REPORT.md")
    args = ap.parse_args()

    if not os.path.exists(args.results):
        sys.exit(f"{args.results} not found - run run_experiments.py first.")
    data = json.load(open(args.results, encoding="utf-8"))
    is_mock = data["meta"]["provider"] == "mock"
    if is_mock:
        args.pdf = args.pdf.replace(".pdf", "_MOCK_DO_NOT_SUBMIT.pdf")
        args.md = args.md.replace(".md", "_MOCK_DO_NOT_SUBMIT.md")

    sections, pending = load_analysis(args.analysis)
    if pending:
        print("Note: analysis.md still has TODO / empty sections: " + ", ".join(pending) +
              "\n      The report will show '[Analysis not written yet]' there. Write them before you submit.",
              file=sys.stderr)

    blocks = build_blocks(data, sections, pending, is_mock)
    footer = f"Prompt Engineering Report - {data['meta']['model']} - generated {datetime.date.today().isoformat()}"
    render_pdf(blocks, args.pdf, footer)
    os.makedirs(os.path.dirname(args.md) or ".", exist_ok=True)
    with open(args.md, "w", encoding="utf-8") as f:
        f.write(render_md(blocks))
    print(f"Wrote {args.pdf}\nWrote {args.md}")


if __name__ == "__main__":
    main()

"""
evaluate.py - scoring functions. Pure Python, no dependencies.

Every function takes the model's raw text and returns a dict with at least:
  pred     canonical prediction (used to measure consistency across repeated runs)
  correct  bool
"""
import json
import re

LABELS = ["positive", "negative", "neutral", "mixed"]
JSON_KEYS = {"name", "date", "amount", "currency"}
_NUMBER = r"-?\d[\d,]*(?:\.\d+)?"


# ---- Experiment 1: sentiment ------------------------------------------------

def eval_sentiment(raw: str, expected: str) -> dict:
    low = raw.strip().lower()
    cleaned = low.strip(" .!\"'\n\t")
    format_ok = cleaned in LABELS  # the model replied with exactly one label and nothing else
    if format_ok:
        pred = cleaned
    else:  # fall back to the earliest label mentioned anywhere in the reply
        hits = []
        for label in LABELS:
            m = re.search(r"\b" + label + r"\b", low)
            if m:
                hits.append((m.start(), label))
        pred = min(hits)[1] if hits else None
    return {"pred": pred, "correct": pred == expected, "format_ok": format_ok}


# ---- Experiment 2: numeric answers -----------------------------------------

def _to_float(text: str) -> float:
    return float(text.replace(",", ""))


def eval_number(raw: str, expected: float, marker: bool = False) -> dict:
    """marker=True: the prompt asked for a final line 'ANSWER: <number>'."""
    text = raw.strip()
    pred, format_ok = None, False
    if marker:
        found = re.findall(r"ANSWER:\s*\$?\s*(" + _NUMBER + ")", text, flags=re.I)
        if found:
            pred = _to_float(found[-1])
            format_ok = text.splitlines()[-1].strip().upper().startswith("ANSWER:")
    if pred is None:  # fallback: last number in the reply
        nums = re.findall(_NUMBER, text)
        if nums:
            pred = _to_float(nums[-1])
    if not marker:
        format_ok = bool(re.fullmatch(r"\$?\s*" + _NUMBER + r"\s*\.?", text))
    correct = pred is not None and abs(pred - expected) < 1e-6
    return {"pred": pred, "correct": correct, "format_ok": format_ok}


# ---- Experiment 3: JSON extraction -----------------------------------------

def _schema_ok(obj) -> bool:
    if not isinstance(obj, dict) or set(obj) != JSON_KEYS:
        return False
    if not isinstance(obj["name"], str) or not obj["name"].strip():
        return False
    if not isinstance(obj["date"], str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", obj["date"]):
        return False
    if isinstance(obj["amount"], bool) or not isinstance(obj["amount"], (int, float)):
        return False
    if not isinstance(obj["currency"], str) or not re.fullmatch(r"[A-Z]{3}", obj["currency"]):
        return False
    return True


def eval_json(raw: str, expected: dict) -> dict:
    result = {"valid_json_raw": False, "valid_json_cleaned": False, "schema_ok": False,
              "correct": False, "field_errors": [], "parsed": None, "pred": None}
    obj = None
    try:
        obj = json.loads(raw)
        result["valid_json_raw"] = True
    except (json.JSONDecodeError, TypeError):
        # Lenient second attempt: take the first {...} block (strips ```json fences / chatter).
        m = re.search(r"\{.*\}", raw or "", flags=re.S)
        if m:
            try:
                obj = json.loads(m.group(0))
            except json.JSONDecodeError:
                obj = None
    if obj is None:
        result["field_errors"] = ["no parseable JSON"]
        return result

    result["valid_json_cleaned"] = True
    result["parsed"] = obj
    result["pred"] = json.dumps(obj, sort_keys=True, ensure_ascii=False)
    result["schema_ok"] = _schema_ok(obj)

    if not isinstance(obj, dict):
        result["field_errors"] = ["not a JSON object"]
        return result
    errors = []
    for key in ("name", "date", "currency"):
        if obj.get(key) != expected[key]:
            errors.append(key)
    amount = obj.get("amount")
    if isinstance(amount, bool) or not isinstance(amount, (int, float)) or abs(amount - expected["amount"]) > 0.005:
        errors.append("amount")
    extra = set(obj) - JSON_KEYS
    if extra:
        errors.append("extra keys: " + ", ".join(sorted(extra)))
    result["field_errors"] = errors
    result["correct"] = result["schema_ok"] and not errors
    return result

"""
prompts.py - every prompt template, test input and expected answer used in the project.

Nothing in here talks to an API. Edit this file to add your own prompt iterations
(e.g. a 4th JSON prompt variant); run_experiments.py picks them up automatically.

Placeholders: every template uses {input}, which is replaced with the test input.
"""


def render(template: str, **kwargs) -> str:
    """Tiny str.replace-based renderer (str.format would choke on the JSON braces)."""
    out = template
    for key, value in kwargs.items():
        out = out.replace("{" + key + "}", str(value))
    return out


# ---------------------------------------------------------------------------
# Experiment 1 - zero-shot vs few-shot: sentiment classification
# ---------------------------------------------------------------------------
# 4 labels on purpose: "mixed" and sarcasm are where zero-shot prompts tend to wobble.

SENTIMENT_TEST = [
    {"id": 1,  "input": "Absolutely loved the battery life, it easily lasts two days.", "expected": "positive"},
    {"id": 2,  "input": "Arrived broken and customer support never replied to my emails.", "expected": "negative"},
    {"id": 3,  "input": "It's fine. Does what it says on the box, nothing more.", "expected": "neutral"},
    {"id": 4,  "input": "Oh great, another update that wipes all my settings. Just what I needed.", "expected": "negative"},
    {"id": 5,  "input": "The screen is gorgeous, but the speakers are tinny and it overheats.", "expected": "mixed"},
    {"id": 6,  "input": "Not bad at all, I expected much worse.", "expected": "positive"},
    {"id": 7,  "input": "Delivery took three days.", "expected": "neutral"},
    {"id": 8,  "input": "I can't believe how much money I wasted on this. Never again.", "expected": "negative"},
    {"id": 9,  "input": "Great food, terrible service - I'd only go back for takeout.", "expected": "mixed"},
    {"id": 10, "input": "Five stars. Would buy again!", "expected": "positive"},
]

# Examples shown to the model in the few-shot prompt. None of them appear in SENTIMENT_TEST.
SENTIMENT_FEWSHOT_EXAMPLES = [
    ("The camera is superb and setup took two minutes.", "positive"),
    ("Stopped working after a week, total waste of money.", "negative"),
    ("The package contains a cable and a manual.", "neutral"),
    ("Love the design, but the app crashes constantly.", "mixed"),
    ("Yeah, because waiting 40 minutes on hold is exactly what I wanted.", "negative"),
]

_SENTIMENT_INSTRUCTION = (
    "Classify the sentiment of the text as one of: positive, negative, neutral, mixed.\n"
    "Reply with only the label, in lowercase."
)

_FEWSHOT_BLOCK = "\n\n".join(
    f"Text: {text}\nSentiment: {label}" for text, label in SENTIMENT_FEWSHOT_EXAMPLES
)

SENTIMENT_ZERO_SHOT = _SENTIMENT_INSTRUCTION + "\n\nText: {input}\nSentiment:"
SENTIMENT_FEW_SHOT = _SENTIMENT_INSTRUCTION + "\n\n" + _FEWSHOT_BLOCK + "\n\nText: {input}\nSentiment:"


# ---------------------------------------------------------------------------
# Experiment 2 - chain-of-thought vs direct answer: multi-step word problems
# ---------------------------------------------------------------------------
# Expected answers are all verified by hand (worked solutions in the comments).

COT_PROBLEMS = [
    {   # Monday 40, Tuesday 80 -> 120 sold. Margin $2 -> $240. Costs 2 x $60 = $120. Profit $120.
        "id": 1, "expected": 120.0,
        "input": ("A store buys notebooks at $3 each and sells them at $5 each. It sold 40 notebooks on "
                  "Monday and twice as many on Tuesday. It also paid $60 of fixed costs on each of the two "
                  "days. What was the store's total profit in dollars over the two days?"),
    },
    {   # Head start: 45 min x 60 km/h = 45 km. Closing speed 30 km/h -> 1.5 h. 90 x 1.5 = 135 km.
        "id": 2, "expected": 135.0,
        "input": ("A train leaves a station at 9:15 AM travelling at 60 km/h. A second train leaves the same "
                  "station at 10:00 AM, on the same track and in the same direction, travelling at 90 km/h. "
                  "How many kilometres from the station are the trains when the second train catches up?"),
    },
    {   # Net fill 20 - 5 = 15 L/min. Needs 600 - 90 = 510 L. 510 / 15 = 34 min.
        "id": 3, "expected": 34.0,
        "input": ("A 600-litre tank currently holds 90 litres. Pipe A fills it at 20 litres per minute while "
                  "pipe B drains it at 5 litres per minute, and both run at the same time. After how many "
                  "minutes is the tank exactly full?"),
    },
    {   # R = 3S. R - 12 = S + 12 -> 3S - 12 = S + 12 -> S = 12 -> R = 36.
        "id": 4, "expected": 36.0,
        "input": ("Ravi has three times as many marbles as Sam. Ravi gives 12 of his marbles to Sam, and "
                  "afterwards they have exactly the same number. How many marbles did Ravi have originally?"),
    },
    {   # Original x: 0.75 x 1.10 = 0.825 x = 99 -> x = 120.
        "id": 5, "expected": 120.0,
        "input": ("A jacket is discounted by 25% from its original price, and then a 10% sales tax is added to "
                  "the discounted price. The final price paid is $99. What was the original price in dollars?"),
    },
    {   # c + k = 30, 2c + 4k = 74 -> 2k = 74 - 60 = 14 -> k = 7 cows.
        "id": 6, "expected": 7.0,
        "input": ("A farmer has only chickens and cows. Together they have 30 heads and 74 legs. "
                  "How many cows does the farmer have?"),
    },
]

COT_DIRECT = (
    "Solve the problem below. Reply with ONLY the final numerical answer - "
    "no words, no units, no working.\n\nProblem: {input}\n\nAnswer:"
)

COT_STEP_BY_STEP = (
    "Solve the problem below. Think step by step and show each calculation. "
    "Then, on the very last line, write exactly: ANSWER: <number>\n\nProblem: {input}"
)


# ---------------------------------------------------------------------------
# Experiment 3 - structured output: messy text -> strict JSON
# ---------------------------------------------------------------------------
# Target schema: {"name": str, "date": "YYYY-MM-DD", "amount": number, "currency": ISO-4217 code}
# The inputs deliberately contain traps: titles, locale number formats, "15k", relative vs absolute
# dates, ambiguous dd/mm vs mm/dd, and a distractor date.

EXTRACTION_TEST = [
    {"id": 1,
     "input": "Hi team, just a reminder that Priya Sharma paid us ₹12,500 on 3rd March 2026 for the design work.",
     "expected": {"name": "Priya Sharma", "date": "2026-03-03", "amount": 12500, "currency": "INR"}},
    {"id": 2,
     "input": "invoice #4471 -- received from Mr. John O'Neil, $1,299.50 usd, dated Nov 7, 2025. thx",
     "expected": {"name": "John O'Neil", "date": "2025-11-07", "amount": 1299.5, "currency": "USD"}},
    {"id": 3,
     "input": ("On the fifteenth of January 2026, Maria-Luisa Fernández transferred €2.400 "
               "(two thousand four hundred euros) to the account."),
     "expected": {"name": "Maria-Luisa Fernández", "date": "2026-01-15", "amount": 2400, "currency": "EUR"}},
    {"id": 4,
     "input": "Ref 88-A: 04/09/2026 - Chen Wei - £75 (approx.). Note: dates in this log are UK format.",
     "expected": {"name": "Chen Wei", "date": "2026-09-04", "amount": 75, "currency": "GBP"}},
    {"id": 5,
     "input": "Dr. Aisha Khan sent 15k rupees on 12 Aug 2026 - please log it.",
     "expected": {"name": "Aisha Khan", "date": "2026-08-12", "amount": 15000, "currency": "INR"}},
    {"id": 6,
     "input": "Payment of 3,450.75 CAD from Tom Baker was recorded on 2026-02-28 at 4:15pm (ticket closed 03/01).",
     "expected": {"name": "Tom Baker", "date": "2026-02-28", "amount": 3450.75, "currency": "CAD"}},
]

# v1 - naive: no schema, no format guidance (the baseline).
EXTRACT_V1_NAIVE = "Extract the name, date, and amount from this text:\n\n{input}"

# v2 - explicit schema in the prompt, "JSON only" instruction.
EXTRACT_V2_SCHEMA = (
    "Extract the payment details from the text below.\n"
    "Return ONLY a JSON object with exactly these keys:\n"
    '{"name": string, "date": string (YYYY-MM-DD), "amount": number, "currency": string (ISO 4217 code)}\n\n'
    'Text: """{input}"""'
)

# v3 - schema + explicit rules + two worked examples (not in the test set) + JSON mode at the API level.
EXTRACT_V3_FULL = (
    "You extract payment details from messy text and output strict JSON.\n\n"
    "Schema (all four keys required, no extra keys):\n"
    '{"name": string, "date": string, "amount": number, "currency": string}\n\n'
    "Rules:\n"
    "- name: the payer's full name, without titles such as Mr., Ms., Dr. Keep original spelling and accents.\n"
    "- date: the date the payment was made, formatted YYYY-MM-DD. If the text states a date format "
    "(e.g. UK), follow it. Ignore other dates (invoice dates, ticket dates).\n"
    "- amount: a plain JSON number - no currency symbols, no thousands separators. Interpret locale formats "
    "(1,299.50 = 1299.5; European 2.400 = 2400) and shorthand such as 15k = 15000.\n"
    "- currency: ISO 4217 code (USD, EUR, INR, GBP, ...). Infer it from symbols or words.\n"
    "- Output the JSON object only: no markdown fences, no commentary.\n\n"
    "Example 1\n"
    'Text: """Received 1,050.00 GBP from Ms. Olivia Grant on 2026-05-02."""\n'
    '{"name": "Olivia Grant", "date": "2026-05-02", "amount": 1050, "currency": "GBP"}\n\n'
    "Example 2\n"
    'Text: """Hans Müller paid 3.200 euro on 5 June 2026 (invoice sent 1 June)."""\n'
    '{"name": "Hans Müller", "date": "2026-06-05", "amount": 3200, "currency": "EUR"}\n\n'
    'Text: """{input}"""'
)


# ---------------------------------------------------------------------------
# Registry used by run_experiments.py and build_report.py
# ---------------------------------------------------------------------------

EXPERIMENTS = {
    "sentiment": {
        "title": "Experiment 1 - Zero-shot vs Few-shot prompting",
        "task": "Sentiment classification (positive / negative / neutral / mixed) of 10 short reviews.",
        "goal": ("Hold the instruction constant and change only one thing: whether the prompt contains "
                 "worked examples. The test set includes sarcasm, understatement and mixed-sentiment "
                 "reviews, which are the cases where a bare instruction is most likely to be misread."),
        "items": SENTIMENT_TEST,
        "variants": {
            "zero_shot": {
                "label": "Zero-shot",
                "description": "Instruction only, no examples.",
                "template": SENTIMENT_ZERO_SHOT,
                "json_mode": False,
            },
            "few_shot": {
                "label": "Few-shot (5 examples)",
                "description": "Same instruction, plus 5 labelled examples (one per label, plus a sarcasm case).",
                "template": SENTIMENT_FEW_SHOT,
                "json_mode": False,
            },
        },
    },
    "cot": {
        "title": "Experiment 2 - Chain-of-thought vs Direct answer",
        "task": "Six multi-step arithmetic/algebra word problems with a single numeric answer.",
        "goal": ("Compare a prompt that forces an immediate answer with one that asks the model to reason "
                 "step by step first. Accuracy is scored on the final number only."),
        "items": COT_PROBLEMS,
        "variants": {
            "direct": {
                "label": "Direct answer",
                "description": "Asks for the final number only, no working.",
                "template": COT_DIRECT,
                "json_mode": False,
            },
            "cot": {
                "label": "Chain-of-thought",
                "description": "Asks the model to think step by step, then give 'ANSWER: <number>'.",
                "template": COT_STEP_BY_STEP,
                "json_mode": False,
            },
        },
    },
    "extraction": {
        "title": "Experiment 3 - Structured JSON output",
        "task": ("Extract {name, date, amount, currency} from 6 messy paragraphs containing titles, "
                 "locale-specific numbers, shorthand amounts, ambiguous dates and distractor dates."),
        "goal": ("Iterate on the prompt through three versions and measure, per version: is the output "
                 "parseable JSON as returned, does it match the schema, and are all values correct."),
        "items": EXTRACTION_TEST,
        "variants": {
            "v1_naive": {
                "label": "v1 - Naive",
                "description": "No schema, no format instructions (baseline).",
                "template": EXTRACT_V1_NAIVE,
                "json_mode": False,
            },
            "v2_schema": {
                "label": "v2 - Explicit schema",
                "description": "Schema and 'JSON only' instruction in the prompt.",
                "template": EXTRACT_V2_SCHEMA,
                "json_mode": False,
            },
            "v3_full": {
                "label": "v3 - Schema + rules + examples + JSON mode",
                "description": ("Schema, explicit normalisation rules, two worked examples that are not in the "
                                "test set, and the API's JSON mode switched on."),
                "template": EXTRACT_V3_FULL,
                "json_mode": True,
            },
        },
    },
}

<!--
YOUR WRITTEN ANALYSIS - this is the part reviewers read most closely, and it has to be yours.

How to use this file
1. Run run_experiments.py and open results/raw_results.json (or the "Raw model outputs" section of the report).
2. Replace each TODO block below with your own 2-4 sentences, based on what your model actually did.
3. Delete the TODO word when you are done. build_report.py shows "[Analysis not written yet]" for any
   section that still contains TODO, so you cannot forget one.

Honest results beat impressive ones. If few-shot did not help, or chain-of-thought changed nothing on a
strong model, say so and explain why - the task description says documenting where a technique
DIDN'T help is just as valuable.

Lines starting with "- " become bullet points. **bold** and `code` work. Comments like this one are stripped.
-->

## Experiment 1 - Zero-shot vs Few-shot

<!-- Questions to answer, citing item numbers from the report:
 - Did few-shot change accuracy? Which items flipped (see "Measured" list under the table)?
 - Look at the sarcasm (4) and mixed (5, 9) items. What did zero-shot do with them, in the raw text?
 - Did the output FORMAT change (one lowercase word vs. a sentence)? Which prompt was more consistent?
 - Which example in the few-shot prompt do you think made the difference, and why? -->

TODO: write your analysis of Experiment 1 here.

## Experiment 2 - Chain-of-thought vs Direct

<!-- Questions to answer:
 - Did accuracy improve with "think step by step"? Quote the numbers from the table.
 - Pick one problem and compare the two raw outputs: where did the direct answer go wrong, or where did
   the reasoning visibly help?
 - If both scored the same, why might that be (model strength, problem difficulty)? What would you try next
   (harder problems, a smaller model)?
 - What did CoT cost: output length, latency, format failures? -->

TODO: write your analysis of Experiment 2 here.

## Experiment 3 - Structured JSON output

<!-- Questions to answer:
 - What exactly was wrong with v1's output? (Not parseable? Wrong keys? Free text around the data?)
 - What did v2's explicit schema fix - and what did it NOT fix (look at the failure list, e.g. fences, dates)?
 - Which of v3's additions (rules / examples / JSON mode) fixed which failure? Tie each to a specific item.
 - Which items still fail, and what would you change in the prompt next? Note: v3's examples were chosen
   to be different from the test inputs, so improvements are not just memorisation. -->

TODO: write your analysis of Experiment 3 here.

## Overall lessons

<!-- 3-5 bullets: when you would use each technique, what surprised you, what you would test next
(e.g. a second model, a bigger test set, temperature > 0 with --runs 3 for consistency). -->

TODO: write your overall lessons here.
